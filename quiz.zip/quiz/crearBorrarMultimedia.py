from gtts import gTTS
import os
import time
import tempfile


class CrearBorrarMultimedia:
    def __init__(self, lang: str = 'es'):
        self.lang = lang

    def crear_audio_temporal(self, texto: str) -> str:
        tts = gTTS(text=texto, lang=self.lang)
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.mp3')
        temp_file.close()
        tts.save(temp_file.name)
        return temp_file.name

    def reproducir_audio(self, ruta_archivo: str) -> None:
        if os.name == 'nt':
            os.startfile(ruta_archivo)

    def borrar_archivo(self, ruta_archivo: str) -> None:
        if os.path.exists(ruta_archivo):
            os.remove(ruta_archivo)

    def generar_reproducir_y_borrar(self, texto: str, espera_extra: float = 2.0) -> None:
        ruta = self.crear_audio_temporal(texto)
        self.reproducir_audio(ruta)
        duracion_aprox = max(1.0, len(texto.split()) / 2.5)
        time.sleep(duracion_aprox + espera_extra)
        self.borrar_archivo(ruta)


__all__ = ['CrearBorrarMultimedia']