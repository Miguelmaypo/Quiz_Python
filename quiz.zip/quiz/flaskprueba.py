from flask import Flask, render_template
from Quiz import lista_preguntas
from crearBorrarMultimedia import CrearBorrarMultimedia

app = Flask(__name__)

@app.route('/page1')
def show_template():
    return render_template('page1.html', name='Miguel')


@app.route('/page2')
def show_template2():
    pregunta = lista_preguntas[0]
    opciones = pregunta['opciones']
    for opcion_text in opciones.values():
        CrearBorrarMultimedia(lang='es').generar_reproducir_y_borrar(opcion_text)
    return render_template('page2.html', name='Miguel', opciones=opciones)

@app.route('/page3')
def show_template3():
    return render_template('page3.html', name='Miguel')

if __name__ == '__main__':
    app.run(debug=True)
