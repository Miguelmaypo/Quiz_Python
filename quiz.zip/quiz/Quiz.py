from crearBorrarMultimedia import CrearBorrarMultimedia
import json
import os
import random
from jugadores import jugador_quiz
from pathlib import Path

try:
    import google.generativeai as genai
except ImportError:
    genai = None

GENAI_API_KEY = os.environ.get('GENAI_API_KEY', 'TU_API_KEY')
if genai is not None and GENAI_API_KEY:
    genai.configure(api_key=GENAI_API_KEY)
    model = genai.GenerativeModel('gemini-1.5-flash')
else:
    model = None


def cargar_preguntas():
    ruta_preguntas = Path(__file__).with_name('preguntas.json')
    with ruta_preguntas.open('r', encoding='utf-8') as archivo:
        datos = json.load(archivo)
    lista_preguntas = datos.get('preguntas', [])
    if not lista_preguntas:
        raise ValueError('No se encontraron preguntas en el archivo preguntas.json')
    return lista_preguntas


lista_preguntas = cargar_preguntas()


def generar_pregunta(categoria='Historia'):
    if model is None:
        raise RuntimeError('El paquete google.generativeai no está instalado o no se ha configurado la clave de API.')

    prompt = f'''Genera una pregunta de trivia sobre {categoria}.
Responde SOLO con JSON válido, sin texto extra:
{{
  "pregunta": "...",
  "opciones": ["A) ...", "B) ...", "C) ...", "D) ..."],
  "respuesta_correcta": "A",
  "explicacion": "..."
}}'''

    respuesta = model.generate_content(prompt)
    texto = respuesta.text.strip()

    try:
        datos = json.loads(texto)
    except json.JSONDecodeError as error:
        raise ValueError(f'No se pudo parsear la respuesta de la IA: {error}')

    if not isinstance(datos, dict):
        raise ValueError('La respuesta de la IA no es un objeto JSON válido.')

    return datos


def obtener_pregunta(categoria='Ciencia'):
    if model is not None:
        try:
            return generar_pregunta(categoria)
        except Exception as error:
            print(f'No se pudo generar la pregunta con IA: {error}. Usando pregunta local.')

    return random.choice(lista_preguntas)


def jugar_quiz(num_rondas=2):
    manager = CrearBorrarMultimedia(lang='es')
    manager.generar_reproducir_y_borrar('¡Bienvenidos al Quiz de Cultura General!')
    manager.generar_reproducir_y_borrar('¿Cuántos jugadores van a participar?')

    try:
        numero = int(input().strip())
    except ValueError:
        raise ValueError('Debe introducir un número válido de jugadores.')

    jugadores = []
    for i in range(numero):
        print(f'Nombre del jugador {i + 1}:')
        nombre = input().strip()
        jugadores.append(jugador_quiz(nombre))

    usar_ia = False
    if model is not None:
        respuesta = input('¿Quieres usar preguntas generadas por IA para este quiz? (S/N): ').strip().lower()
        usar_ia = respuesta == 's'

    for ronda in range(num_rondas):
        for jugador in jugadores:
            manager.generar_reproducir_y_borrar(f'Turno de {jugador.nombre}')
            manager.generar_reproducir_y_borrar(f'Puntuación actual: {jugador.puntuacion}')

            if usar_ia:
                pregunta = obtener_pregunta('Ciencia')
            else:
                pregunta = random.choice(lista_preguntas)

            if isinstance(pregunta.get('opciones'), dict):
                opciones = [f'{k.upper()}) {v}' for k, v in pregunta['opciones'].items()]
            else:
                opciones = pregunta.get('opciones', [])

            print('\nPregunta:')
            print(pregunta['pregunta'])
            manager.generar_reproducir_y_borrar(pregunta['pregunta'])

            print('Opciones:')
            for opcion in opciones:
                print(opcion)
                manager.generar_reproducir_y_borrar(opcion)

            respuesta_usuario = input('\nTu respuesta (A/B/C/D): ').strip().lower()
            if 'respuesta_correcta' in pregunta:
                respuesta_correcta = pregunta['respuesta_correcta'].strip().lower()
            else:
                respuesta_correcta = pregunta['respuesta'].strip().lower()

            if respuesta_usuario == respuesta_correcta:
                print('¡Respuesta correcta!')
                jugador.puntuacion += 1
            else:
                print(f'¡Respuesta incorrecta! La respuesta correcta es: {respuesta_correcta.upper()}')
                jugador.puntuacion -= 2

            explicacion = pregunta.get('explicacion', 'No hay explicación disponible.')
            print(f'💡 {explicacion}')
            manager.generar_reproducir_y_borrar(explicacion)

    print('\nPuntuaciones finales:')
    for jugador in jugadores:
        manager.generar_reproducir_y_borrar(f'{jugador.nombre}: {jugador.puntuacion} puntos')
        if jugador.puntuacion >= 2:
            manager.generar_reproducir_y_borrar(f'¡Felicidades {jugador.nombre}, eres el ganador!')
    return jugadores


if __name__ == '__main__':
    jugar_quiz()
