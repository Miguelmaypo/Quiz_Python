
class jugador_quiz:
    def __init__(self, nombre):
        self.nombre = nombre
        self.puntuacion = 0